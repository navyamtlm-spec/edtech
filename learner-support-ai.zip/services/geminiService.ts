
import { GoogleGenAI } from "@google/genai";
import type { Message } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `You are an expert AI assistant for a digital learning platform. Your role is to provide clear, concise, and helpful explanations about course structures, assessment methods, certification processes, and platform navigation. You must be friendly, patient, and encouraging.

**CRITICAL RULE: Under no circumstances will you provide answers, hints, or solutions to any assignments, quizzes, or assessments. If a user asks for an answer to a test question, you must politely decline and explain that your purpose is to help them understand the learning process, not to complete their work for them. Redirect them to course materials or instructors for subject-matter help.**
`;

export const getExplanation = async (prompt: string, history: { role: Message['role']; parts: { text: string }[] }[]): Promise<string> => {
  try {
    const model = 'gemini-3-flash-preview';
    
    const response = await ai.models.generateContent({
        model: model,
        contents: [...history, { role: 'user', parts: [{ text: prompt }] }],
        config: {
            systemInstruction: SYSTEM_INSTRUCTION
        }
    });

    const text = response.text;
    if (text) {
        return text;
    } else {
        throw new Error("No text response from API.");
    }
  } catch (error) {
    console.error("Error fetching from Gemini API:", error);
    throw new Error("Failed to get a response from the AI assistant.");
  }
};
