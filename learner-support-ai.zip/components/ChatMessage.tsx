
import React from 'react';
import type { Message } from '../types';
import { UserIcon, BotIcon } from './IconComponents';

interface ChatMessageProps {
  message: Message;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';
  
  const bubbleClasses = isUser 
    ? 'bg-primary-500 text-white' 
    : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200';
  
  const containerClasses = isUser ? 'justify-end' : 'justify-start';
  
  const icon = isUser 
    ? <UserIcon className="w-6 h-6 text-white" /> 
    : <BotIcon className="w-6 h-6 text-gray-500 dark:text-gray-400" />;
  
  const iconContainerClasses = isUser
    ? 'bg-primary-500 order-2'
    : 'bg-gray-200 dark:bg-gray-700';

  return (
    <div className={`flex items-start gap-4 ${containerClasses}`}>
      {!isUser && (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
          {icon}
        </div>
      )}
      <div
        className={`max-w-xl px-4 py-3 rounded-2xl shadow-md ${bubbleClasses} ${isUser ? 'rounded-br-none' : 'rounded-bl-none'}`}
      >
        <p className="whitespace-pre-wrap">{message.content}</p>
      </div>
      {isUser && (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary-500 flex items-center justify-center">
            {icon}
        </div>
      )}
    </div>
  );
};
