
import React from 'react';

interface ExamplePromptsProps {
  onPromptClick: (prompt: string) => void;
}

const prompts = [
  "How do I check my course progress?",
  "What's the difference between a quiz and an assignment?",
  "Explain the certification process.",
  "Where can I find my grades?",
];

export const ExamplePrompts: React.FC<ExamplePromptsProps> = ({ onPromptClick }) => {
  return (
    <div className="px-4 md:px-6 mb-4">
        <p className="text-sm text-center text-gray-500 dark:text-gray-400 mb-3">Try asking one of these questions:</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {prompts.map((prompt, index) => (
                <button
                key={index}
                onClick={() => onPromptClick(prompt)}
                className="text-left p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 hover:border-primary-400 dark:hover:border-primary-500 transition-all text-sm text-gray-700 dark:text-gray-300"
                >
                {prompt}
                </button>
            ))}
        </div>
    </div>
  );
};
