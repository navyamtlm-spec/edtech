
import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { Message } from './types';
import { getExplanation } from './services/geminiService';
import { ChatInput } from './components/ChatInput';
import { ChatMessage } from './components/ChatMessage';
import { ExamplePrompts } from './components/ExamplePrompts';
import { BotIcon, GraduationCapIcon } from './components/IconComponents';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      content: "Hello! I'm here to help you with any questions about course structures, assessments, or certifications. How can I assist you today?",
    },
  ]);
  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = useCallback(async (prompt?: string) => {
    const userMessageContent = prompt || input;
    if (!userMessageContent.trim() || isLoading) return;

    const newUserMessage: Message = { role: 'user', content: userMessageContent };
    setMessages((prevMessages) => [...prevMessages, newUserMessage]);
    setInput('');
    setIsLoading(true);
    setError(null);

    try {
      const history = messages.map(msg => ({
          role: msg.role,
          parts: [{ text: msg.content }]
      }));
      const botResponse = await getExplanation(userMessageContent, history);
      const newBotMessage: Message = { role: 'model', content: botResponse };
      setMessages((prevMessages) => [...prevMessages, newBotMessage]);
    } catch (err) {
      const errorMessage = 'Sorry, I encountered an error. Please try again.';
      setError(errorMessage);
      setMessages((prevMessages) => [...prevMessages, { role: 'model', content: errorMessage }]);
    } finally {
      setIsLoading(false);
    }
  }, [input, isLoading, messages]);


  return (
    <div className="flex flex-col h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 font-sans">
      <header className="flex items-center p-4 border-b border-gray-200 dark:border-gray-700 shadow-sm">
        <GraduationCapIcon className="h-8 w-8 text-primary-500" />
        <h1 className="text-xl font-bold ml-3">Learner Support AI</h1>
      </header>
      
      <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        {messages.map((msg, index) => (
          <ChatMessage key={index} message={msg} />
        ))}
         {isLoading && (
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                <BotIcon className="w-6 h-6 text-gray-500 dark:text-gray-400" />
              </div>
              <div className="flex items-center space-x-1 pt-2">
                <span className="w-2.5 h-2.5 bg-primary-500 rounded-full animate-pulse delay-0"></span>
                <span className="w-2.5 h-2.5 bg-primary-500 rounded-full animate-pulse delay-150"></span>
                <span className="w-2.5 h-2.5 bg-primary-500 rounded-full animate-pulse delay-300"></span>
              </div>
            </div>
          )}
        {error && <p className="text-red-500 text-center">{error}</p>}
        <div ref={chatEndRef} />
      </main>

       {messages.length <= 1 && (
        <ExamplePrompts onPromptClick={handleSendMessage} />
      )}
      
      <footer className="p-4 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
        <ChatInput 
          input={input}
          setInput={setInput}
          handleSendMessage={handleSendMessage}
          isLoading={isLoading}
        />
      </footer>
    </div>
  );
};

export default App;
